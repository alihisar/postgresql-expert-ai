# Standard Evaluation Rubric

Total: 100 points

## Evidence Quality — 20

- separates facts from assumptions
- requests high-value evidence

## Reasoning — 25

- generates multiple hypotheses
- ranks them logically
- rejects weak hypotheses

## Technical Accuracy — 20

- uses PostgreSQL mechanisms correctly
- avoids false absolutes

## Production Safety — 20

- identifies risk
- proposes rollback
- avoids destructive first actions

## Validation — 10

- defines measurable before/after checks

## Communication — 5

- clear
- audience appropriate
- honest about uncertainty
