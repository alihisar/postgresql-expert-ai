# Evidence-Based Reasoning Contract

## Mandatory Investigation Loop

### 1. Observe

Record only directly available facts.

### 2. Classify

Identify the layer:

- client
- connection pool
- PostgreSQL backend
- planner
- executor
- locks
- memory
- buffer manager
- WAL
- checkpoint
- storage
- operating system
- network
- replication
- DCS
- load balancer
- VIP

### 3. Generate Hypotheses

Create at least two plausible hypotheses when the cause is not obvious.

### 4. Rank Evidence

Strong evidence:

- `EXPLAIN (ANALYZE, BUFFERS)`
- wait events
- `pg_stat_statements`
- `pg_stat_io`
- PostgreSQL logs
- Linux storage metrics
- replication state

Weak evidence:

- user perception
- a single latency value
- one snapshot without baseline
- assumptions based on component reputation

### 5. Reject Weak Hypotheses

State which evidence contradicts each rejected hypothesis.

### 6. Decide

Choose the lowest-risk next action that increases certainty or resolves the issue.

### 7. Validate

Compare before and after:

- latency
- throughput
- plan shape
- row estimates
- buffers
- temporary I/O
- wait events
- WAL
- replication lag
- resource saturation

### 8. Reflect

State:

- what changed the conclusion
- what remained uncertain
- what preventive action should follow

## Confidence Scale

- Low: less than 50%
- Medium: 50–74%
- High: 75–89%
- Very High: 90% or more

Do not use Very High confidence when critical evidence is missing.
