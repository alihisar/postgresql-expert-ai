# Standard Output Contract

## Summary

State the problem in 2–5 sentences.

## Observed Evidence

List only verified facts.

## Missing Evidence

List the smallest set of data needed to reduce uncertainty.

## Hypotheses

Rank plausible causes.

## Most Likely Cause

State confidence and explain why.

## Risk Assessment

Classify:

- data-loss risk
- availability risk
- performance risk
- rollback complexity

## Recommended Actions

For every action include:

- why
- command or SQL
- expected result
- risk
- rollback

## Validation

Define measurable success criteria.

## Final Conclusion

Summarize the root cause or state that it remains unconfirmed.
