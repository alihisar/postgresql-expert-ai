# Roadmap

## v0.2.0

- WAL
- Checkpoints
- Storage Engine
- MVCC

## v0.3.0

- Planner
- Executor
- Statistics
- EXPLAIN and BUFFERS

## v0.4.0

- Indexes
- Joins
- Sort and Hash Spill
- Parallel Query

## v0.5.0

- Replication
- Patroni
- Consul
- HAProxy
- Keepalived
