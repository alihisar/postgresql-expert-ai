# Enterprise PostgreSQL Expert AI

> Train AI systems to think, investigate, reason, and make safe engineering decisions like an Enterprise PostgreSQL DBA.

## Purpose

This repository is an English-language, AI-first curriculum for PostgreSQL and its production ecosystem.

It is not a glossary.

It is designed to teach:

- mechanisms
- mental models
- evidence-based reasoning
- diagnosis
- risk assessment
- rollback planning
- validation
- production communication

## Training Structure

Each competency contains:

- `lesson.md`
- `workbook.md`
- `lab.md`
- `evaluation.md`
- `gold-answer.md`
- `decision-tree.md`
- `metadata.yaml`

## Included in v0.1.0

1. Think Like a PostgreSQL DBA
2. Understand PostgreSQL Architecture
3. Understand Memory Architecture
4. Diagnose Buffer Manager Behavior

## Language Policy

All training content is written in English.

The runtime model should answer in the user's language while preserving official PostgreSQL terminology.

## Recommended Runtime Order

1. `framework/system.md`
2. `framework/reasoning.md`
3. `framework/output.md`
4. Relevant competency files
5. User question

## Project Motto

> Teach AI how an Enterprise PostgreSQL DBA thinks, investigates, decides, and validates.
