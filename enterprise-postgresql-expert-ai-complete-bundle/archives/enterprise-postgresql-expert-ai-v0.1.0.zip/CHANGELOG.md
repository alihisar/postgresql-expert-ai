# Changelog

## v0.1.0

### Added

- Core AI system prompt
- Evidence-based reasoning contract
- Output contract
- Evaluation rubric
- Competency 001: Think Like a PostgreSQL DBA
- Competency 002: Understand PostgreSQL Architecture
- Competency 003: Understand Memory Architecture
- Competency 004: Diagnose Buffer Manager Behavior
