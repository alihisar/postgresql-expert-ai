# Roadmap

## Faz 1 — Temel model davranışı

- [x] System prompt
- [x] Short rules
- [x] Output format
- [x] 10 HA few-shot örneği

## Faz 2 — DBA temelleri ve upgrade

- [x] PostgreSQL architecture
- [x] Minor upgrade
- [x] pg_upgrade
- [x] Blue/green logical upgrade
- [x] Minor upgrade checklist
- [x] Patroni rolling restart playbook
- [x] Consul quorum loss playbook

## Faz 3 — Performance

- [ ] EXPLAIN ve EXPLAIN ANALYZE
- [ ] BUFFERS ve I/O
- [ ] Seq Scan / Index Scan
- [ ] Join algoritmaları
- [ ] Sort ve hash spill
- [ ] Statistics ve planner hataları

## Faz 4 — Backup ve recovery

- [ ] pgBackRest
- [ ] Barman
- [ ] pg_basebackup
- [ ] PITR
- [ ] Restore validation
- [ ] Disaster recovery drill

## Faz 5 — HA derinleşme

- [ ] Patroni architecture
- [ ] Consul internals
- [ ] HAProxy read/write routing
- [ ] Keepalived VRRP
- [ ] Split-brain prevention
- [ ] Failover/failback

## Faz 6 — Operasyon ve güvenlik

- [ ] Monitoring
- [ ] Security hardening
- [ ] Capacity planning
- [ ] Linux troubleshooting
- [ ] Incident response ve RCA
