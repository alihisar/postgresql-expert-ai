# Roadmap

## v0.1 — Framework Foundation

- [x] Repository mission and structure
- [x] English system prompt
- [x] Short rules
- [x] Output contract
- [x] Evidence-based reasoning contract
- [x] RAG metadata standard
- [x] Contribution and safety policies
- [ ] Migrate legacy uppercase directories
- [ ] Add baseline evaluation tests

## v0.2 — PostgreSQL Core

- [ ] Process model
- [ ] Memory architecture
- [ ] Buffer manager
- [ ] WAL internals
- [ ] MVCC and snapshots
- [ ] VACUUM and freezing
- [ ] Storage layout
- [ ] Lock manager
- [ ] Planner and executor

## v0.3 — Performance

- [ ] `EXPLAIN` and `EXPLAIN ANALYZE`
- [ ] `BUFFERS`, WAL, I/O timing, and temporary files
- [ ] scans, joins, aggregates, and sorts
- [ ] statistics and cardinality estimation
- [ ] index design
- [ ] parallel query and JIT
- [ ] production performance decision trees

## v0.4 — High Availability

- [ ] physical and logical replication
- [ ] Patroni architecture and DCS behavior
- [ ] Consul quorum and failure modes
- [ ] HAProxy routing and health checks
- [ ] Keepalived and VRRP
- [ ] PgBouncer
- [ ] split-brain prevention and response

## v0.5 — Operations

- [ ] backup, restore, and PITR
- [ ] minor and major upgrades
- [ ] rolling HA maintenance
- [ ] monitoring and observability
- [ ] security and access control
- [ ] incident response and RCA
- [ ] capacity planning

## v1.0 — Production-Ready Knowledge Framework

- [ ] reviewed knowledge set
- [ ] validated playbooks and runbooks
- [ ] RAG ingestion guide
- [ ] local LLM integration examples
- [ ] automated Markdown and link checks
- [ ] evaluation suite and release documentation
