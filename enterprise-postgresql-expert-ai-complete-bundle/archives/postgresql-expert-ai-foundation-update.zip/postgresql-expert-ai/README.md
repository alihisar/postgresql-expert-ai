# Enterprise PostgreSQL Expert AI Framework

An open-source, AI-first knowledge framework for PostgreSQL DBAs, platform engineers, performance specialists, and high-availability architects.

## Project Goals

This repository is designed to support:

- local LLM system prompts and expert profiles;
- retrieval-augmented generation (RAG);
- few-shot and evaluation datasets;
- human-readable operational documentation;
- production playbooks, runbooks, checklists, and decision trees;
- PostgreSQL performance, reliability, upgrades, backup, recovery, and HA operations.

## Scope

The framework covers:

- PostgreSQL architecture, WAL, MVCC, VACUUM, locking, storage, and configuration;
- query planning, `EXPLAIN`, statistics, indexes, and performance analysis;
- physical and logical replication;
- Patroni, Consul, HAProxy, Keepalived, and PgBouncer;
- backup, restore, PITR, disaster recovery, and upgrade strategies;
- Linux, networking, storage, observability, security, and capacity planning;
- incident response, root-cause analysis, and change validation.

## Language Policy

Repository content is written in English to maximize compatibility with official documentation and local LLMs.

The expert prompt follows the user's language:

- Turkish input → Turkish answer;
- English input → English answer;
- PostgreSQL object names, parameters, plan nodes, commands, and log messages remain in their original form.

## Quick Start

### Ollama

Use the framework files in this order:

1. `framework/system/00_SYSTEM_PROMPT.md`
2. `framework/system/01_SHORT_RULES.md`
3. `framework/output/00_OUTPUT_FORMAT.md`
4. selected examples from `framework/few-shot/`
5. relevant documents from `knowledge/`, `playbooks/`, `runbooks/`, and `checklists/`

Example `Modelfile`:

```dockerfile
FROM qwen3.5:14b

PARAMETER temperature 0.15
PARAMETER top_p 0.9
PARAMETER repeat_penalty 1.1
PARAMETER num_ctx 4096

SYSTEM """
Paste the merged framework system, short-rules, and output-format files here.
"""
```

A 7B–8B Q4 model is usually a better fit than a 14B model on a 16 GB RAM, CPU-only system, especially when using longer contexts.

## Repository Structure

```text
framework/       AI behavior, reasoning, output rules, few-shot data, RAG standards
knowledge/       Conceptual and operational PostgreSQL knowledge
playbooks/       Incident-response procedures
runbooks/        Planned operational procedures
checklists/      Pre-change, execution, validation, and rollback checklists
decision-trees/  Evidence-based troubleshooting paths
examples/        SQL, logs, plans, and analysis examples
labs/            Reproducible learning environments
scripts/         DBA diagnostic and validation scripts
benchmark/       pgbench, fio, and performance experiments
tests/           Prompt and knowledge evaluation cases
```

Legacy uppercase directories are retained temporarily for migration compatibility. New content should use the lowercase structure.

## Safety

This project provides decision support and educational guidance. It must not be used as an unattended production automation engine.

Potentially destructive actions require:

- human approval;
- a verified backup or recovery path;
- a documented rollback plan;
- environment and version validation;
- post-change verification.

## Roadmap

See [ROADMAP.md](ROADMAP.md).

## License

MIT. See [LICENSE](LICENSE).
