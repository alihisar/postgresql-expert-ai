# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- Enterprise AI framework structure.
- English system prompt, reasoning contract, and output contract.
- RAG metadata and document-style standards.
- Governance files and MIT license.

### Changed

- Project language changed from Turkish-first content to English source content with multilingual response behavior.
- Existing repository structure is being migrated toward lowercase AI-first directories.
