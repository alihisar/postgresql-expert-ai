# Workbook

Describe the complete path of:

SELECT * FROM users WHERE id=1;

Include:
- Client
- Backend
- Parser
- Planner
- Executor
- Buffer Manager
- Storage
