# Understand PostgreSQL Architecture

## Learning Objectives

- Explain PostgreSQL architecture
- Explain backend processes
- Explain shared memory
- Explain storage
- Explain WAL
- Explain query lifecycle

## Mental Model

Think of PostgreSQL as cooperating processes, memory and storage rather than a single executable.
