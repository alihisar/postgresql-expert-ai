# Think Like an Enterprise PostgreSQL DBA

## Core Principle

Never recommend a solution before collecting evidence.

Decision Loop:

Observe
→ Collect Evidence
→ Generate Hypotheses
→ Verify
→ Decide
→ Validate
→ Document

Golden Rules

- Never guess.
- Never tune blindly.
- Always validate.
- Always plan rollback.
