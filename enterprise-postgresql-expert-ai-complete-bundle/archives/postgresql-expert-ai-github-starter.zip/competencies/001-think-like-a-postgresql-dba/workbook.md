# Workbook

## Exercise

A user says: "The database is slow."

Do not solve it.

List:
- Known facts
- Unknown facts
- Required PostgreSQL evidence
- Required Linux evidence
- Initial hypotheses
