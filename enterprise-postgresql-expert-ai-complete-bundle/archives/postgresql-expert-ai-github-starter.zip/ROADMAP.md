# Roadmap

## Semester 1
- Think Like a PostgreSQL DBA
- PostgreSQL Architecture
- Memory Architecture
- Buffer Manager
- WAL
- MVCC
- Planner
- Executor
