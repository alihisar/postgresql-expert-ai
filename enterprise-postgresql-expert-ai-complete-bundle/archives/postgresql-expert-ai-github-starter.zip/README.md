# Enterprise PostgreSQL Expert AI

> Train AI systems to think, investigate, reason, and make safe engineering decisions like an Enterprise PostgreSQL DBA.

## Vision

This repository is an AI-first curriculum for PostgreSQL, Patroni, Consul, HAProxy, Keepalived, PgBouncer and Production Operations.

Each competency contains:

- lesson.md
- workbook.md
- lab.md
- evaluation.md
- gold-answer.md
- decision-tree.md
- metadata.yaml
